package com.example.bookshop.Jaas;

public class LoginManager {
}
